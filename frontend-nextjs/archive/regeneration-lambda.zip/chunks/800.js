"use strict";
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 92800:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;